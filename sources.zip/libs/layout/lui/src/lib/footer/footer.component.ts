import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'pb-lui-footer',
  template: `
    <p>
      footer works!
    </p>
  `,
  styles: [
  ],
})
export class FooterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
