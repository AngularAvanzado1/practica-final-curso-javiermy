export * from './lib/contregions.module';
