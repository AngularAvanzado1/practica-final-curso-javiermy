export interface Wellcome {
  message: string;
}
