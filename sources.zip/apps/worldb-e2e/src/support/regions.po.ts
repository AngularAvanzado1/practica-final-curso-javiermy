export const visitRegions = () => cy.visit('/regions');
export const getSection = () => cy.get('section');
export const getH2 = () => cy.get('h2');
export const getMain = () => cy.get('main');
