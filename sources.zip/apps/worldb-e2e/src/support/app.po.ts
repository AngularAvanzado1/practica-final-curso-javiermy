export const visitHome = () => cy.visit('/');
export const getA = () => cy.get('a');
export const getH1 = () => cy.get('h1');
export const getP = () => cy.get('p');
